var namespaces =
[
    [ "VSLib", "d1/dce/namespace_v_s_lib.html", "d1/dce/namespace_v_s_lib" ]
];