var class_v_s_lib_1_1_h_u_d_1_1_menu =
[
    [ "Menu", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a2051734fd2fb015a08a1d5e051cce0d7", null ],
    [ "AddOption", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a68a048d001fcbab2fe03e3fbdccf8c60", null ],
    [ "CloseMenu", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a8a9227457264a237be567e22a7bd04cc", null ],
    [ "Detach", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#aaea1d69e2bffc856f5466ab8bc05a121", null ],
    [ "DisplayMenu", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#ac5e6162cc6494db071d95bc9baa52c1b", null ],
    [ "GetString", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#adfaba18aef87a0072e317bf0bf8aa0af", null ],
    [ "OverrideButtons", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#af7901a547023ea0f55fc7f6ccf234524", null ],
    [ "ResizeHeightByLines", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#af2cc17947b987ea9abd73def781ee654", null ],
    [ "SetHighlightStrings", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a47b10c7006ecde8ad9025677cfbe5b1f", null ],
    [ "SetOptionFormat", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#aa1f4bf677e0e43c58a7ef7a365af3752", null ],
    [ "SetTitle", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a929fea75f5d543dbd0e9236de1f8ba6b", null ],
    [ "Tick", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html#a65eb676c48d91aadd093b8eb0f42b88b", null ]
];