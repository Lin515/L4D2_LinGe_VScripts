var namespace_v_s_lib_1_1_easy_logic =
[
    [ "Objects", "d3/d64/class_v_s_lib_1_1_easy_logic_1_1_objects.html", "d3/d64/class_v_s_lib_1_1_easy_logic_1_1_objects" ],
    [ "Players", "de/d5f/class_v_s_lib_1_1_easy_logic_1_1_players.html", "de/d5f/class_v_s_lib_1_1_easy_logic_1_1_players" ]
];