var hierarchy =
[
    [ "VSLib.Entity", "d0/dd6/class_v_s_lib_1_1_entity.html", [
      [ "VSLib.Player", "db/dfb/class_v_s_lib_1_1_player.html", null ]
    ] ],
    [ "VSLib.FileIO", "d0/d4a/class_v_s_lib_1_1_file_i_o.html", null ],
    [ "VSLib.function", "d7/d64/class_v_s_lib_1_1function.html", null ],
    [ "VSLib.HUD.Item", "d0/d66/class_v_s_lib_1_1_h_u_d_1_1_item.html", [
      [ "VSLib.HUD.Bar", "da/dda/class_v_s_lib_1_1_h_u_d_1_1_bar.html", null ],
      [ "VSLib.HUD.Countdown", "d0/d7e/class_v_s_lib_1_1_h_u_d_1_1_countdown.html", null ],
      [ "VSLib.HUD.Menu", "d0/d25/class_v_s_lib_1_1_h_u_d_1_1_menu.html", null ]
    ] ],
    [ "VSLib.EasyLogic.Objects", "d3/d64/class_v_s_lib_1_1_easy_logic_1_1_objects.html", null ],
    [ "VSLib.EasyLogic.Players", "de/d5f/class_v_s_lib_1_1_easy_logic_1_1_players.html", null ],
    [ "VSLib.QAngle", "d3/d56/class_v_s_lib_1_1_q_angle.html", null ],
    [ "VSLib.RandomItemSpawner", "db/d2b/class_v_s_lib_1_1_random_item_spawner.html", null ],
    [ "VSLib.Timers", "d8/dbe/class_v_s_lib_1_1_timers.html", null ],
    [ "VSLib.Utils", "d5/dbe/class_v_s_lib_1_1_utils.html", null ],
    [ "VSLib.Vector", "dd/d8e/class_v_s_lib_1_1_vector.html", null ]
];